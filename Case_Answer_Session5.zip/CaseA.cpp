#include<stdio.h>
#include<string.h>

int main(){
	int n;
	scanf("%d",&n);
	
	for(int k = 0; k<n;k++){
		char x[15];
		scanf("%s",x);
		int count = 0;
		for(int i = 0 ;i<strlen(x);i++){
			if(x[i]=='4'){
				count++;				
			}
		}
		
		printf("%d\n",count);
		
	}
	
	return 0;
}
