#include<stdio.h>
#include<string.h>

int main(){
    char x[205];
    scanf("%s", x);
    for (int i = 0; i<strlen(x); i++){
        // cek sesuai dengan soal
        // jika karakternya . saja langsung print 0
        if (x[i] == '.'){
            printf("0");
        }
        // jika karakternya -, cek apakah karakter selanjutnya . atau - dan print sesuai dengan permintaan soal 
        // yaitu antara 1 atau 2
        else if (x[i] == '-'){
            if (x[i + 1] == '.'){
                printf("1");
            }
            else {
                printf("2");
            }
            i++;
        }
    }

    return 0;
}
