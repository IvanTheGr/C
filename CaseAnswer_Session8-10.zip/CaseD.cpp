#include<stdio.h>

int main(){
	int tc;
	scanf("%d",&tc);
	
	while(tc--){
		int x;
		scanf("%d",&x);
		if(x<38){
			printf("%d\n",x);
		}else{
			int mod = x%5;
			if(mod>=3){
				printf("%d\n",x + (5-mod));
			}else{
				printf("%d\n",x);
			}
		}
	}
	
}
