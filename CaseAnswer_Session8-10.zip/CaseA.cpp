#include<stdio.h>

int function(int m,int n){
	if(m==0 || m ==n){
		return 1;
	}else{
		return function(m-1,n-1)+function(m,n-1);
	}
	
}

int main(){
	int m,n;
	scanf("%d %d",&n,&m);
	
	printf("%d\n",function(m,n));
	
	return 0;
}
