#include <stdio.h>
#include <string.h>

int main(){
	int x;
	
	
	scanf("%d",&x);
	for(int i=0;i<x;i++){
		char y[101];
		scanf("%s",&y);
		int z=strlen(y);
		if(z>10){
			char a=y[0];
			int b=z-2;
			char c=y[z-1];
			printf("%c%d%c\n",a,b,c);
		}else{
			printf("%s\n",y);
			
		}
		
	}
}
