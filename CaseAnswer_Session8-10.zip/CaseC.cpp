#include<stdio.h>
#include<string.h>

int main(){
	char x[102],y[102],z[102];
	
	scanf("%s",x);
	scanf("%s",y);
	scanf("%s",z);
	
	int arr1[26]={0};
	int arr2[26]={0};
	
	for(int i=0;i<strlen(x);i++){
		arr1[x[i]-'A']+=1;
	}
	
	for(int i=0;i<strlen(y);i++){
		arr1[y[i]-'A']+=1;
	}
	
	for(int i=0;i<strlen(z);i++){
		arr2[z[i]-'A']+=1;
	}
	
	int flag=0;
	for(int i=0;i<26;i++){
		if(arr1[i]!=arr2[i]){
			printf("NO\n");
			flag=1;
			break;
		}
	}
	
	if(flag==0){
	printf("YES\n");
	}
	
	
	return 0;
}
